using cie2a.Models;
using Microsoft.AspNetCore.Mvc;

namespace cie2a.Controllers
{
    public class CourseController : Controller
    {
        private static readonly List<Course> courses = new()
        {
            new Course
            {
                CourseId = 1,
                CourseName = "ASP.NET Core MVC",
                Duration = "3 Months",
                Fees = 15000,
                DiscountPercentage = 10
            },

            new Course
            {
                CourseId = 2,
                CourseName = "C# Programming",
                Duration = "2 Months",
                Fees = 10000,
                DiscountPercentage = 15
            },

            new Course
            {
                CourseId = 3,
                CourseName = "Web Development",
                Duration = "4 Months",
                Fees = 20000,
                DiscountPercentage = 20
            },

            new Course
            {
                CourseId = 4,
                CourseName = "Database Management",
                Duration = "2 Months",
                Fees = 12000,
                DiscountPercentage = 10
            }
        };

        public IActionResult Index()
        {
            return View(courses);
        }

        public IActionResult Details(int id)
        {
            var course = courses.FirstOrDefault(c => c.CourseId == id);

            if (course == null)
            {
                return NotFound();
            }

            return View(course);
        }
    }
}