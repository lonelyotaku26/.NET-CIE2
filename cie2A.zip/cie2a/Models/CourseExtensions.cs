namespace cie2a.Models
{
    public static class CourseExtensions
    {
        public static decimal CalculateFinalFees(this Course course)
        {
            decimal discountAmount =
                course.Fees * course.DiscountPercentage / 100;

            return course.Fees - discountAmount;
        }
    }
}